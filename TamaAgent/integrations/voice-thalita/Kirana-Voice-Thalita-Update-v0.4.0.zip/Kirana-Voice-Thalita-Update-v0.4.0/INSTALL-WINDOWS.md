# Patch seletivo — Kirana v0.4.0 Thalita Neural

## Importante antes de instalar

O TTS solicitado usa `rany2/edge-tts` 7.3.1 contra Microsoft Edge Read Aloud. É um serviço online não documentado como API pública suportada e pode falhar/mudar; o texto dos trechos de fala sai do PC para Microsoft. Não envie conteúdo sensível e não assuma direitos comerciais/redistribuição de áudio. O Gateway textual SIWC continua independente, sem alteração OAuth ou credenciais.

## Instalação Windows preservando `.env` e a sessão SIWC

1. Extraia este ZIP para uma pasta temporária. Não extraia por cima da instalação.
2. Deixe o Gateway existente (porta 1455) rodando para manter a sessão SIWC em memória. No terminal do servidor de voz 1456, pressione `Ctrl+C` para parar somente o cliente de voz.
3. Copie **somente** os arquivos abaixo da pasta do patch para os mesmos caminhos da instalação existente:
   - `examples/voice-client/voice.html`
   - `examples/voice-client/app.js`
   - `examples/voice-client/providers.js`
   - `examples/voice-client/edge-tts-adapter.js`
   - `examples/voice-client/edge-tts-runner.mjs`
   - `examples/voice-client/edge_tts_worker.py`
   - `examples/voice-client/tts-routing.js`
   - `examples/voice-client/requirements-edge-tts.txt`
   - `examples/voice-client/server.mjs`

   Não substitua `.env`, `.local-state`, `src/`, `package.json`, `package-lock.json` ou quaisquer outros arquivos/configurações. Não rode Setup de novo.

4. Em PowerShell, na raiz da instalação, confira Python Launcher e instale a dependência só no perfil do usuário:

   ```powershell
   py -3 --version
   py -3 -m pip install --user -r .\examples\voice-client\requirements-edge-tts.txt
   ```

   Isso não edita `.env` nem o repositório. O servidor usa `py -3` por padrão. Para um Python específico, defina `KIRANA_EDGE_TTS_PYTHON` no ambiente do processo que inicia `npm run voice` (não é necessário colocar nada no `.env`).

5. Na raiz do Gateway, rode novamente `npm run voice`. Abra `http://127.0.0.1:1456` e faça `Ctrl+F5`. O Gateway/porta 1455 não precisa ser reiniciado.
6. Valide em Edge/Chromium: DevTools Network deve mostrar `/app.js`, `/edge-tts-adapter.js`, `/tts-routing.js`, `/providers.js` como 200 JavaScript, `/api/tts/voices` com `pt-BR-ThalitaMultilingualNeural`, e `/api/tts/stream` com `audio/mpeg`. Console sem erro CSP; verifique chip SIWC/modelos; faça uma resposta e ouça áudio; teste Interromper e fallback se a voz Francisca estiver exposta no browser. O relatório/captura de tela não deve incluir `.env`, tokens, cookies, texto privado ou áudio de usuário.

## Dependência e portas

- Node já instalado para o Gateway (>=20). Não muda dependências npm.
- Python 3 + `edge-tts==7.3.1` (pin em `requirements-edge-tts.txt`).
- Interface e proxy continuam presos a `127.0.0.1:1456`. TTS faz apenas chamadas de saída à Microsoft; nenhum listener público é criado.
- O botão Interromper cancela a request textual e o stream TTS e pede ao Node para encerrar o worker Python ativo.

## Limite da validação deste patch

O pacote Python e a voz foram consultados e áudio MP3 real foi sintetizado nesta revisão; o proxy Node também foi exercitado com serviço real. O playback audível/MSE, Francisca fallback e interrupção física ainda precisam ser confirmados no Windows de destino. Não considerar concluído antes dessa checagem real.
