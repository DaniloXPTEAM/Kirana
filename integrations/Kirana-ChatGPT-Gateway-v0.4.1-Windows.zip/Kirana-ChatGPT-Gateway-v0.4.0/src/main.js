import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createGateway } from './gateway.js';

await loadEnv(resolve(process.cwd(), '.env'));
const apiKey = process.env.GATEWAY_API_KEY;
if (!apiKey) {
  console.error('GATEWAY_API_KEY is missing. Run npm run keygen and put its output in .env (chmod 600 .env).');
  process.exit(1);
}
const port = Number(process.env.PORT || 1455);
const appName = process.env.APP_NAME || 'Kirana Personal Gateway';
const appId = process.env.APP_ID || 'kirana-personal-gateway';
if (!/^[a-z0-9][a-z0-9._-]{0,99}$/.test(appId)) throw new Error('APP_ID must be a stable lowercase slug.');
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('PORT must be an integer from 1024 to 65535.');
const fileMaxBytes = Number(process.env.FILE_MAX_BYTES || 10 * 1024 * 1024);
const fileTtlSeconds = Number(process.env.FILE_TTL_SECONDS || 3600);
const fileMaxTotalBytes = Number(process.env.FILE_MAX_TOTAL_BYTES || 50 * 1024 * 1024);
const fileMaxCount = Number(process.env.FILE_MAX_COUNT || 50);
if (!Number.isInteger(fileMaxBytes) || fileMaxBytes < 1024 || fileMaxBytes > 250 * 1024 * 1024) throw new Error('FILE_MAX_BYTES must be an integer from 1024 to 262144000.');
if (!Number.isInteger(fileTtlSeconds) || fileTtlSeconds < 60 || fileTtlSeconds > 86400) throw new Error('FILE_TTL_SECONDS must be an integer from 60 to 86400.');
if (!Number.isInteger(fileMaxTotalBytes) || fileMaxTotalBytes < fileMaxBytes || fileMaxTotalBytes > 2 * 1024 * 1024 * 1024) throw new Error('FILE_MAX_TOTAL_BYTES must be at least FILE_MAX_BYTES and no more than 2147483648.');
if (!Number.isInteger(fileMaxCount) || fileMaxCount < 1 || fileMaxCount > 500) throw new Error('FILE_MAX_COUNT must be an integer from 1 to 500.');
const providerEnvironment = {
  'images.analyze': 'KIRANA_IMAGE_ANALYSIS_PROVIDER',
  'images.generate': 'KIRANA_IMAGE_GENERATION_PROVIDER',
  'images.edit': 'KIRANA_IMAGE_EDIT_PROVIDER',
  'video.analyze': 'KIRANA_VIDEO_ANALYSIS_PROVIDER',
  'video.generate': 'KIRANA_VIDEO_GENERATION_PROVIDER',
  'audio.transcribe': 'KIRANA_SPEECH_TO_TEXT_PROVIDER',
  'audio.synthesize': 'KIRANA_TEXT_TO_SPEECH_PROVIDER',
};
const providerPreferences = Object.fromEntries(Object.entries(providerEnvironment).flatMap(([capability, variable]) => {
  const value = process.env[variable]?.trim();
  if (!value) return [];
  if (!/^[a-z0-9][a-z0-9._-]{0,63}$/i.test(value)) throw new Error(`${variable} must be a provider identifier (letters, numbers, dot, underscore, hyphen).`);
  return [[capability, value]];
}));
const app = createGateway({ apiKey, appName, stateDir: resolve('.local-state', appId), port, host: process.env.HOST || '127.0.0.1', providerPreferences, fileOptions: { maxFileBytes: fileMaxBytes, maxTotalBytes: fileMaxTotalBytes, maxFiles: fileMaxCount, ttlSeconds: fileTtlSeconds } });
const address = await app.listen();
console.log(`Kirana Personal Gateway v0.4.0 listening at http://127.0.0.1:${address.port}`);
console.log('Private localhost only. Start the explicit ChatGPT consent flow at http://127.0.0.1:' + address.port + '/auth/start');
console.log('Gateway API key authenticates only to this local gateway; it is not an OpenAI or ChatGPT credential.');
console.log('OAuth tokens are memory-only and are cleared when this process exits. No credentials are logged.');

for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, async () => {
  console.log(`Received ${signal}; clearing in-memory credentials and stopping.`);
  try { await app.close(); } finally { process.exit(0); }
});

async function loadEnv(path) {
  let text;
  try { text = await readFile(path, 'utf8'); } catch (e) { if (e.code === 'ENOENT') return; throw e; }
  for (const line of text.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!match || match[1] in process.env) continue;
    let value = match[2];
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    process.env[match[1]] = value;
  }
}
